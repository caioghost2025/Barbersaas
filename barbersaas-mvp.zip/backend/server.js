import express from 'express';
const app = express();
app.use(express.json());

let agendamentos = [];

app.get('/api/agendamentos', (req, res) => {
  res.json(agendamentos);
});

app.post('/api/agendamentos', (req, res) => {
  const novo = req.body;
  agendamentos.push(novo);
  res.status(201).json(novo);
});

app.listen(3000, () => console.log('Servidor rodando na porta 3000'));