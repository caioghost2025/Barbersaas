# BarberSaaS MVP

MVP para agendamento em barbearias.

Rodar no Bolt.new para testar online.